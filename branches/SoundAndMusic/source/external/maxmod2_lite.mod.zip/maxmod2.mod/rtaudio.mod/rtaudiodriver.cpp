#include "rtaudiodriver.h"

extern "C" {
	//ron: added int api as param
	IMaxModAudioDriver* CreateAudioDriver_RtAudio( int api )          {return new RtAudioDriver(api);}
	void CloseAudioDriver_RtAudio(IMaxModAudioDriver* Driver) {delete static_cast<RtAudioDriver*>(Driver);}
}

int RtCallback( void *outputBuffer, void *inputBuffer, unsigned int nBufferFrames,double streamTime, RtAudioStreamStatus status, void *data ) {
	MaxMod_ProcessChannels(outputBuffer,nBufferFrames);
	return 0;
}

// ______________________________________________________________________________________________________________

//ron: added int api
RtAudioDriver::RtAudioDriver(int api){
	//std::cout<<"api:"<<api<<endl;
	//create new audio object with correct api
	RtAudioDriver::SetAPI(api);

	mmPrint("RtAudioDriver::RtAudioDriver");
	Terminate = 0;
	Active = 0;
	//unsigned int devices = dac.getDeviceCount();
	unsigned int devices = audio->getDeviceCount();
	if ( devices<1 ) {mmPrint("No audio output device found!"); return;}
	else {mmPrint("Audio drivers found=",(int)devices);}


	//parameters.deviceId     = dac.getDefaultOutputDevice();
	parameters.deviceId     = audio->getDefaultOutputDevice();
	parameters.nChannels    = 2;
	parameters.firstChannel = 0;
	bufferFrames            = 1024;
}

RtAudioDriver::~RtAudioDriver(){
	mmPrint("~RtAudioStream");
	if (!Terminate) Shutdown();
}

//ron - make used API configurable
int RtAudioDriver::SetAPI( int api) {
	//std::cout<<"SetAPI:"<<api;

	switch(api) {
		case 1:		audio = new RtAudio(RtAudio::LINUX_ALSA);break;
		case 2:		audio = new RtAudio(RtAudio::LINUX_PULSE);break;
		case 3:		audio = new RtAudio(RtAudio::LINUX_OSS);break;
		case 4:		audio = new RtAudio(RtAudio::UNIX_JACK);break;
		case 5:		audio = new RtAudio(RtAudio::MACOSX_CORE);break;
		case 6:		audio = new RtAudio(RtAudio::WINDOWS_ASIO);break;
		case 7:		audio = new RtAudio(RtAudio::WINDOWS_DS);break;
		default:	audio = new RtAudio(RtAudio::UNSPECIFIED);break;
	}
	return 1;
}

int RtAudioDriver::Startup(){
	if (Active==1) return 1;
	mmPrint("RtAudioDriver::Startup");
	options.flags = RTAUDIO_SCHEDULE_REALTIME;
	options.numberOfBuffers = 3;
	options.priority = 1;
//	dac.openStream( &parameters, NULL, RTAUDIO_FLOAT32, 44100, &bufferFrames, &RtCallback, this, &options );
//	dac.startStream();
	audio->openStream( &parameters, NULL, RTAUDIO_FLOAT32, 44100, &bufferFrames, &RtCallback, this, &options );
	audio->startStream();
	Active=1;
	return 1;
}

int RtAudioDriver::Shutdown(){
	mmPrint("RtAudioDriver::Shutdown");
	Terminate=1;
//	dac.closeStream();
	audio->closeStream();
	return 1;
}

IMaxModSound* RtAudioDriver::CreateSound( int samplerate, int channels, int bits, int flags, void* data, int size ){
}

