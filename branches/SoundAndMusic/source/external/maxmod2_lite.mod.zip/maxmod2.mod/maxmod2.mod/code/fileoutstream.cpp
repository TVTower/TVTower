#include "maxmod2.h"

void MaxMod_OutputWavFile(IMaxModMusic* music, char* dst) {
}

