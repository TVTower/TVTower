Kommt in BlitzMax\mod

Es wurde ein Fix in "_addTests" vorgenommen.
Im alten Code (der ausschlie�lich Reflection nutzte) kam es zu einem Error.